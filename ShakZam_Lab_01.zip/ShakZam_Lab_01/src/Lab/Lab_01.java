/*
*   Name: Zamanuddin Shakadam
*   Date: January 18th, 2022
*   Description: This is a simple java program to print Hello World.
*/

package Lab;

public class Lab_01 {

    public static void main(String[] args) {

        System.out.println("Hello World");  // This line prints the 'Hello World' in console.
    }
}
